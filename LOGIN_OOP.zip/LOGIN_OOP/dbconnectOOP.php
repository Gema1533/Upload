<?php 

      try 

      { 

           $con = new PDO('mysql:host=localhost;dbname=kel_2', 'root', '', array(PDO::ATTR_PERSISTENT => true)); 

      } 

      catch(PDOException $e) 

      { 

           echo $e->getMessage(); 

      } 

      include_once 'dataOOP.php'; 

      $user = new data($con); 

 ?> 