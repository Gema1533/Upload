<?php  
/* require 'function.php';

if(isset($_POST["login"])){

  $username = $_POST ["username"];
  $password = $_POST ["password"];

  $result = mysqli_query($link,"SELECT * FROM login WHERE username = '$username'");
  if(mysqli_num_rows($result) === 1){

    $row = mysqli_fetch_assoc($result);
    if(password_verify($password, $row["password"])){
      header("Location: home.php");
      exit;}
  }
  $error = true; 
}*/

 require_once "dbconnectOOP.php";

   //jika ada data yg dikirim 

   if(isset($_POST['login'])){ 

     $email = $_POST['email']; 

     $password = $_POST['password']; 

     // Proses login user 

     if($user->login($email, $password)){ 

       header("location: home.php"); 

     }else{ 

       // Jika login gagal, ambil pesan error 

       $error = $user->getLastError(); 

     } 

   } 

?>
<!DOCTYPE html>
<html>
<head>
<style>
	#card{
		background: -webkit-linear-gradient(#B11B40, #E9AE09);
		height: 430px;
		opacity:0.9;
		width: 360px;
		box-shadow: 1px 2px 8px rgba(0, 0, 1.65);
		border-radius: 20px;
		margin: 7rem auto 5.1rem auto;}
	#pading{
		padding:10px 44px;}
	#card-title {
      font-family: "Raleway Thin", sans-serif;
      letter-spacing: 4px;
      padding-bottom: 23px;
      padding-top: 20px;
      font-size: 20px; 
      color: white;
      color: -webkit-linear-gradient(right, #a1477b, #3e506f);
      text-align: center;}
    .underline-title {
      background: -webkit-linear-gradient(right,#000000, #FFFEF9);
      height: 1.5px;
      text-align:center;
      margin: 0.5rem auto 0 auto;
      width: 100px;
  	  text-decoration:none; }
  	.form {
      padding-left:30px;
      padding-top: 10px;
      color: white;
      display: flex;
      flex-direction: column;}
     .form-input {
	    background: #fbfbfb;
	    border: none;
	    width:285px; 
	    font-size: 15px;
	    border-radius:10px;
	    outline: none;
	    padding:10px;}
	  #submit-btn {
	    background: -webkit-linear-gradient(#B11B40,#E11E09);
	    border: none;  
	    border-radius: 21px;
	    box-shadow: 0px 1px 8px #A4c64f;
	    cursor: pointer;
	    color: white;
	    font-family: "Raleway SemiBold", sans-serif;
	    height: 42.3px;
	    font-size:20px;
	    margin-top: 35px;
	    transition: 0.25s;
	    width: 153px;
		height:40px;
		margin-left:80px}
	 #submit-btn:hover {
   	    box-shadow: 0px 1px 18px white;}
   	 #a{
   	 	color:white;}
   	 #a:hover{
   	 	color:black;}
   

</style>
	<link rel="stylesheet" type="text/css" href="DSGN.css">
	<title>Login</title>
</head>
<body style="background-size: cover;font-family: sans-serif;" background="img\clarisse-meyer-jKU2NneZAbI-unsplash.jpg">
<!--msg-->
<?php if (isset($error)) {
	# code...
	echo "<script>
	alert (' username atau password salah ');
	</script>";
}
?>
<!-- --->
<div id="card">
	<div id="padding">
		<div id="card-title">
			LOGIN
		<div class="underline-title"></div>
		</div>

	<!-- body card -->
	
	<form action="" method="post" class="form">
		<!-- username -->
		<label for="username"
		style="font-size:23px">
		&nbsp;email
		</label>
	   <input 
	   placeholder="isi email disini" 
	   id="username"
	   class="form-input"
	   type="text"
	   name="email"
	   required="" 
	   style="margin-top:10px;size: 406px" />
 	  
 	   <!-- password -->

 	   <label for="password"
		style="font-size:23px;padding-top:10px">
		&nbsp;Password
		</label>
	   <input 
	   placeholder="isi password disini" 
	   id="password"
	   class="form-input"
	   type="password"
	   name="password"
	   required="" 
	   style="margin-top:10px;size: 406px;" />
 	   

 	  
 	  <!-- login -->
 	  <input value="Login" id="submit-btn" type="submit"  name="login">
 	  <!-- lupa password -->
 	  <a id="a" style="text-decoration:none;" href="#">
 	  <legend  style="padding-top: 10px;
     	font-size:15px;padding-bottom:10px;margin-left:105px">
     	Lupa Password ?</legend></a>
 	  <!-- buat akun -->
 	  <a href="buat_akun.php" id="a" style="font-size: 15px;margin-left: 120px;text-decoration: none;">Buat Akun ?</a> </form>

	</div>
</div>
</body>
</html>