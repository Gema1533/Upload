<?php  
   class data
   { 
     private $db; //Menyimpan Koneksi database 
     private $error; //Menyimpan Error Message 
     ## Contructor untuk class Auth, membutuhkan satu parameter yaitu koneksi ke database ## 
     function __construct($db_conn) { 
       $this->db = $db_conn; 
       // Mulai session  
       session_start(); 
     } 
     ### Start : Registrasi User baru ###  
     public function register($nama, $email, $password) { 
       try { 
         // buat hash dari password yang dimasukkan 
         $hashPasswd = password_hash($password, PASSWORD_DEFAULT); 
         //Masukkan user baru ke database 
         $nd = $this->db->prepare("INSERT INTO loginn(nama, email, password) VALUES(:nama, :email, :pass)"); 
         $nd->bindParam(":nama", $nama); 
         $nd->bindParam(":email", $email); 
         $nd->bindParam(":pass", $hashPasswd); 
         $nd->execute(); 
         return true; 
          }
       catch(PDOException $e){ 
         // Jika terjadi error 
         if($e->errorInfo[0] == 23000){ 
           //errorInfor 0 berisi informasi error tentang query sql yg baru dijalankan 
           //23000 adalah kode error ketika ada data yg sama pada kolom yg di set unique 
           $this->error = "Email sudah digunakan!"; 
           return false; 
         }else{ 
           echo $e->getMessage(); 
           return false; 
         } 
       } 
     } 
     ### Start : fungsi login user ###  
     public function login($email, $password){ 
       try { 
         // Ambil data dari database 
         $nd = $this->db->prepare("SELECT * FROM loginn WHERE email = :email"); 
         $nd->bindParam(":email", $email); 
         $nd->execute(); 
         $data = $nd->fetch(); 
         // Jika jumlah baris > 0 
         if($nd->rowCount() > 0){ 
           // jika password yang dimasukkan sesuai dengan yg ada di databand
           if(password_verify($password, $data['password'])){ 
             $_SESSION['user_session'] = $data['id']; 
             return true; 
           }else{ 
             $this->error = "Email atau Password Salah"; 
             return false; 
           } 
         }else{ 
           $this->error = "Email atau Password Salah"; 
           return false; 
         } 
       } catch (PDOException $e) { 
         echo $e->getMessage(); 
         return false; 
       } 
     }  
     // Start : fungsi cek login user  
     public function isLoggedIn(){ 
       // Apakah user_session sudah ada di session 
       if(isset($_SESSION['user_session'])) { 
         return true; 
       } 
     }   
     // st art: fungsi ambil data user yang sudah login ###   
     public function getUser(){ 
       // Cek apakah sudah login 
       if(!$this->isLoggedIn()){ 
         return false; 
       } 
       try { 
         // Ambil data user dari database 
         $nd = $this->db->prepare("SELECT * FROM loginn WHERE id = :id"); 
         $nd->bindParam(":id", $_SESSION['user_session']); 
         $nd->execute(); 
         return $nd->fetch(); 
        } 
         catch (PDOException $e) { 
         echo $e->getMessage(); 
         return false; 
       } 
     } 
     ### Start : fungsi error   
     public function getLastError(){ 
       return $this->error; 
     } 
     ### End : fungsi ambil error terakhir yg disimpan di variable error ###  
   } 
 ?> 