<?php  
/*
 require 'function.php';
if(isset($_POST['daftar'])){
	if (registrasi($_POST) > 0) {
		# code...
		echo 
		"<script>
            alert('Data berhasil di tambahkan!')
            document.location.href ='login.php';
         </script>";
	}else{
		echo mysqli_error($link);
	}
}
*/

   require_once "dbconnectOOP.php";  

   //Cek adanya data yang dikirim 

   if(isset($_POST['daftar'])){ 

     $nama = $_POST['nama']; 

     $email = $_POST['email']; 

     $password = $_POST['password']; 

     // Registrasi user baru 

     if($user->register($nama, $email, $password)){ 

       // Jika berhasil set variable success ke true 

       $success = true; 

     }else{ 

       // Jika gagal, ambil pesan error 

       $error = $user->getLastError(); 

     } 

   } 
  ?> 

<!DOCTYPE html>
<html>
<style type="text/css">
	#card{
		background: -webkit-linear-gradient(#B11B40, #E9AE09);
		height: 450px;
		opacity:0.9;
		width: 360px;
		box-shadow: 1px 2px 8px rgba(0, 0, 1.65);
		border-radius: 20px;
		margin: 6.5rem auto 1.1rem auto;}
	#pading{
		padding:10px 44px;}
	#card-title {
      font-family: "Raleway Thin", sans-serif;
      letter-spacing: 4px;
      padding-bottom: 23px;
      padding-top: 20px;
      font-size: 20px; 
      color: white;
      color: -webkit-linear-gradient(right, #a1477b, #3e506f);
      text-align: center;}
    .underline-title {
      background: -webkit-linear-gradient(right,#1A6FF0, #FFFEF9);
      height: 1.5px;
      text-align:center;
      margin: 0.5rem auto 0 auto;
      width: 100px;
  	  text-decoration:none; }
  	.form {
      padding-left:30px;
      padding-top: 10px;
      color: white;
      display: flex;
      flex-direction: column;}
     .form-input {
	    background: #fbfbfb;
	    border: none;
	    width:285px; 
	    font-size: 15px;
	    border-radius:10px;
	    outline: none;
	    padding:10px;}
	  #submit-btn {
	    background: -webkit-linear-gradient(#B11B40,#E11E09);
	    border: none;  
	    border-radius: 21px;
	    box-shadow: 0px 1px 8px #A4c64f;
	    cursor: pointer;
	    color: white;
	    font-family: "Raleway SemiBold", sans-serif;
	    height: 42.3px;
	    margin-left: 80px ;
	    font-size:20px;
	    margin-top: 35px;
	    transition: 0.25s;
	    width: 153px;
		height:40px}
	 #submit-btn:hover {
   	    box-shadow: 0px 1px 18px white;}


</style>
<head>
	<title>create account</title>
</head>
<body style="background-size: 1000;background-position:center; font-family: sans-serif;" background="img\book_lies_sofa_library_68253_1366x768.jpg">
		<?php  
			if (isset($error)) {
				echo $error;
			}elseif (isset($success)) {
						echo 
						"<script>
				            alert('Data berhasil di tambahkan!')
				            document.location.href ='login.php';
				         </script>";
			}
		?>
	<div id="card">
		<div id="padding">

			<div id="card-title">
				Daftar
			<div class="underline-title"></div>
			</div>

	<form action="" method="post" class="form">
		<!-- username -->
		<label for="username"
		style="font-size:23px">
		&nbsp;name</label>
	   <input 
	   placeholder="buat username anda" 
	   id="username"
	   class="form-input"
	   type="text"
	   name="nama"
	   autocomplete="off" 
	   required="" 
	   style="margin-top:10px;size: 406px" />
 	 <!--- EMAIL -->	
 	 `<label for="email"
		style="font-size:23px">
		&nbsp;Email</label>
	   <input 
	   placeholder="masukan email anda" 
	   id="email"
	   class="form-input"
	   type="email"
	   name="email"
	   autocomplete="off" 
	   required="" 
	   style="margin-top:10px;size: 406px" />

 	   <!-- password -->

 	   <label for="password"
		style="font-size:23px;padding-top:10px">
		&nbsp;Password
		</label>
	   <input 
	   placeholder="buat password anda" 
	   id="password"
	   class="form-input"
	   type="password"
	   name="password"
	   autocomplete="off" 
	   required="" 
	   style="margin-top:10px;size: 406px;" />

	 
 	   <!-- buat akun -->
 	   <input value="Buat Akun" type="submit" name="daftar" id="submit-btn">


		</div>
	</div>

	

</body>
</html>